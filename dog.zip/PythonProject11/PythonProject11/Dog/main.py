import sys, pygame
from Dog import Dog

# inicializar o pygame
pygame.init()

# configurações gerais
fps = 60
size = width, height = 800, 600
speed = [2, 2]
preto = 0, 0, 0

screen = pygame.display.set_mode(size)

dog = Dog(screen, fps)

ball = pygame.image.load("intro_ball.gif")
ballrect = ball.get_rect()

last_ticks = pygame.time.get_ticks()

while True:
    ticks = pygame.time.get_ticks()
    keys = pygame.key.get_pressed()

    # sair da simulação
    if keys[pygame.K_ESCAPE]:
        sys.exit()
    for event in pygame.event.get():
        if event.type == pygame.QUIT: sys.exit()

    # limpa o ecrã
    screen.fill(preto)

    # interage com o cachorro
    if ticks - last_ticks > fps * 4:
        if keys[pygame.K_DOWN]:
            last_ticks = ticks
            dog.go_down()
        elif keys[pygame.K_UP]:
            last_ticks = ticks
            dog.go_up()
        elif keys[pygame.K_LEFT]:
            last_ticks = ticks
            dog.go_left()
        elif keys[pygame.K_RIGHT]:
            last_ticks = ticks
            dog.go_right()
        elif keys[pygame.K_SPACE]:
            last_ticks = ticks
            dog.go_jump()

    ballrect = ballrect.move(speed)
    if ballrect.left < 0 or ballrect.right > width:
        speed[0] = -speed[0]
    if ballrect.top < 0 or ballrect.bottom > height:
        speed[1] = -speed[1]

    # atualiza a bola
    screen.blit(ball, ballrect)
    # atualiza o cachorro
    dog.go(screen)
    # atualiza o ecrã
    pygame.display.flip()
    # avança a simulação
    pygame.time.Clock().tick(fps)