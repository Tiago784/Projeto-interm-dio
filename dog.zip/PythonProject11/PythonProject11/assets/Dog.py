import pygame

class Dog:
    _stand = ('assets/dog_stand.png')
    _seated = 'assets/dog_seated.png'
    _sleep = 'assets/dog_sleep.png'
    _jump = 'assets/dog_jump.png'
    _scale = 90
    _movement_steps = 10
    last_jump = 'still'
    last_jump_tick = -1

    def __init__(self, screen, fps):
        self.screen = screen
        self.fps = fps
        self.stand = pygame.image.load(self._stand)
        self.stand = pygame.transform.scale(self.stand, (self._scale, self._scale))
        self.left = pygame.transform.flip(self.stand, True, False)
        self.left = pygame.transform.scale(self.left, (self._scale, self._scale))
        self.seated = pygame.image.load(self._seated)
        self.seated = pygame.transform.scale(self.seated, (self._scale, self._scale))
        self.sleep = pygame.image.load(self._sleep)
        self.sleep = pygame.transform.scale(self.sleep, (self._scale, self._scale))
        self.jump = pygame.image.load(self._jump)
        self.jump = pygame.transform.scale(self.jump, (self._scale, self._scale))
        self.jump_left = pygame.transform.flip(self.jump, True, False)
        self.state = self.stand
        self.last_direction = self.state
        _bottom = screen.get_height() - self.state.get_rect().height
        self.position = self.state.get_rect().move([0, _bottom])

    def go_jump(self):
        if self.state == self.stand:
            self.state = self.jump
        elif self.state == self.left:
            self.state = self.jump_left

    def go_left(self):
        self.state = self.left
        if self.position.left > 0:
            self.position = self.position.move([-self._movement_steps, 0])
        self.last_direction = self.state

    def go_right(self):
        self.state = self.stand
        if self.position.right < self.screen.get_width():
            self.position = self.position.move([self._movement_steps, 0])
        self.last_direction = self.state

    def go_down(self):
        match self.state:
            case self.stand | self.left:
                self.state = self.seated
                self.position = self.position.move([0, self.position.height * 0.08])
            case self.seated:
                self.state = self.sleep
                self.position = self.position.move([0, self.position.height * 0.21])

    def go_up(self):
        match self.state:
            case self.sleep:
                self.state = self.seated
                self.position = self.position.move([0, self.position.height * -0.21])
            case self.seated:
                self.state = self.last_direction
                self.position = self.position.move([0, self.position.height * -0.08])

    def go(self, screen):
        if self.state == self.jump and self.last_direction == self.stand and self.last_jump == 'still':
            # inicia saltar para a direita
            self.last_jump_tick = pygame.time.get_ticks()
            self.position = self.position.move([self._movement_steps, -self._movement_steps])
            self.last_jump = 'right'
        elif self.state == self.jump and self.last_jump == 'right':
            # terminar de saltar da direita
            if pygame.time.get_ticks() - self.last_jump_tick > self.fps * 6:
                self.position = self.position.move([self._movement_steps, self._movement_steps])
                self.state = self.last_direction
                self.last_jump = 'still'
        elif self.state == self.jump_left and self.last_direction == self.left and self.last_jump == 'still':
            # inicia saltar para a esquerda
            self.last_jump_tick = pygame.time.get_ticks()
            self.position = self.position.move([-self._movement_steps, -self._movement_steps])
            self.last_jump = 'left'
        elif self.state == self.jump_left and self.last_jump == 'left':
            # terminar de saltar da esquerda
            if pygame.time.get_ticks() - self.last_jump_tick > self.fps * 6:
                self.position = self.position.move([-self._movement_steps, self._movement_steps])
                self.state = self.last_direction
                self.last_jump = 'still'

        screen.blit(self.state, self.position)