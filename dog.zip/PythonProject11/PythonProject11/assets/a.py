import random

def battle_game():
    player_hp = 100
    monster_hp = 100

    print("🐉 A wild monster appears!")
    print("You have 100 HP. The monster has 100 HP.")

    while player_hp > 0 and monster_hp > 0:
        print("\nWhat do you want to do?")
        print("1) Attack")
        print("2) Heal")
        print("3) Run")

        choice = input("> ")

        if choice == "1":
            player_damage = random.randint(10, 25)
            monster_damage = random.randint(5, 20)

            monster_hp -= player_damage
            player_hp -= monster_damage

            print(f"💥 You deal {player_damage} damage!")
            print(f"🔥 The monster hits you for {monster_damage} damage!")

        elif choice == "2":
            heal = random.randint(15, 30)
            monster_damage = random.randint(5, 20)

            player_hp += heal
            player_hp -= monster_damage

            print(f"💚 You heal {heal} HP!")
            print(f"🔥 The monster hits you for {monster_damage} damage!")

        elif choice == "3":
            print("🏃 You ran away safely!")
            return
        else:
            print("❌ Invalid choice!")
            continue

        player_hp = max(player_hp, 0)
        monster_hp = max(monster_hp, 0)

        print(f"❤️ Your HP: {player_hp}")
        print(f"👹 Monster HP: {monster_hp}")

    if player_hp > 0:
        print("\n🎉 You defeated the monster!")
    else:
        print("\n☠️ You were defeated...")

battle_game()

